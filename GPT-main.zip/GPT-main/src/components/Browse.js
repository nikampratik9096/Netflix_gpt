import React from 'react'

const Browse = () => {
    
  return (
    <div>
      <h1>browse</h1>
    </div>
  )
}

export default Browse
