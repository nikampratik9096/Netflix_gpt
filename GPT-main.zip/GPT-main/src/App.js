import Body from "./components/Body";

function App() {
  return (
    <Body/>
  );
}

export default App;
